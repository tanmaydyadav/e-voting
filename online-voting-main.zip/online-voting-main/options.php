<?php
session_start();
if (!isset($_SESSION["logged-in"]) || $_SESSION["logged-in"] !== true) {
    header("location: admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Options</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
        h1 {
            display: flex;
            /* border: 2px solid red; */
            align-items: center;
            color: #4e4e4e;
            justify-content: center;
            font-size: 398%;
        }

        .container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .wrapper {
            width: 715px;
            margin: 0 auto;
            padding: 5px;
            /* border: 2px solid blue; */
            display: flex;
            justify-content: space-between;
            flex-direction: row;
            flex-wrap: wrap;
            align-content: center;
            margin-top: 7%;
        }

        .btn1 {
            border: 5px solid #0000007a;
            border-radius: 15px;
            padding: 40px;
            display: flex;
            flex-direction: column;
            background-color: #ffffff30;
        }

        .btn1 img {
            height: 135px;
            width: 145px;
            padding: 5px;
            margin: 5px;
        }

        .btn2 {
            border: 5px solid #0000007a;
            border-radius: 15px;
            padding: 40px;
            display: flex;
            flex-direction: column;
            background-color: #ffffff30;

        }

        .btn2 img {
            height: 135px;
            width: 145px;
            padding: 5px;
            margin: 5px;
        }

        .result {
            color: white;
            border: 2px solid red;
            background: #337ab7;
            border-color: #2e6da4;
            border-radius: 4px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 7%;
            width: 110px;
            height: 41px;
        }

        .result:hover {
            background-color: #286090;
            border-color: #204d74;
        }

        .result a:hover {
            text-decoration: none;
        }

        .wrapper::before {
            background: url('https://media.istockphoto.com/id/1148772178/photo/indian-voter-hand-with-voting-sign-after-casting-vote-in-election.jpg?s=612x612&w=0&k=20&c=omunlFcNxvgO_nAS_-31pJ-HfuF8TwMjwTcRlxd67uM=') no-repeat center center/cover;
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.3;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</head>

<body>
    <h1>Admin Portal</h1>
    <div class="container">
        <div class="wrapper">
            <div class="btn1">
                <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="">
                <a href="candidates-add.php" class="btn btn-primary center">Manage Candidates</a>
            </div>
            <div class="btn2">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Circle-icons-profile.svg/2048px-Circle-icons-profile.svg.png"
                    alt="">
                <a href="user-approval.php" class="btn btn-primary center">Manage Users</a>
            </div>
        </div>
        <div class="result">
            <a href="results.php" style="color: white;">Results</a>
        </div>
    </div>
</body>

</html>