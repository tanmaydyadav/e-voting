<?php

// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to admin page
if(!isset($_SESSION["logged-in"]) || $_SESSION["logged-in"] !== true){
    header("location: index.php");
    exit;
}
?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
// Include config file
require("C:/xampp/htdocs/online-voting-main/Exception.php");
require("C:/xampp/htdocs/online-voting-main/PHPMailer.php");
require("C:/xampp/htdocs/online-voting-main/SMTP.php");
require_once "config.php";
$id = $_GET['id'];
$sql = "SELECT * FROM users_approval WHERE id=?";
$stmt = mysqli_prepare($link,$sql);
mysqli_stmt_bind_param($stmt,'i',$id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$array = mysqli_fetch_assoc($result);
$username = $array["username"];
$password= $array['password'];
$email = $array["email"];
$age = $array["age"];
$gender = $array["gender"];
$epic_no = $array["epic_no"];
mysqli_stmt_close($stmt);
$mail = new PHPMailer; 
 
// Server settings 
//$mail->SMTPDebug = SMTP::DEBUG_SERVER;    //Enable verbose debug output 
$mail->isSMTP();                            // Set mailer to use SMTP 
$mail->Host = 'smtp.gmail.com';           // Specify main and backup SMTP servers 
$mail->SMTPAuth = true;                     // Enable SMTP authentication 
$mail->Username = 'ketanyalmate@gmail.com';       // SMTP username 
$mail->Password = 'uqfdxmrgkujmumyo';         // SMTP password 
$mail->SMTPSecure = 'tsl';                  // Enable TLS encryption, `ssl` also accepted 
$mail->Port = 587;                          // TCP port to connect to 
 
// Sender info 
$mail->setFrom('ketanyalmate@gmail.com', 'Ketan Y'); 
//  $mail->addReplyTo('reply@example.com', 'SenderName'); 
 
// Add a recipient 
$mail->addAddress($email); 
 
//$mail->addCC('cc@example.com'); 
//$mail->addBCC('bcc@example.com'); 
 
// Set email format to HTML 
$mail->isHTML(true); 
 
// Mail subject 
$mail->Subject = 'Email  for approval of registration'; 
 
// Mail body content 
$bodyContent = '<h1>' .$username. ' You registration have been confirmed and you are eligible to vote</h1>'; 
$bodyContent .= '<p>This HTML email is sent from the localhost server using PHP by <b>Ketan Y</b></p>'; 
$mail->Body    = $bodyContent; 
 
// Send email 
if(!$mail->send()) { 
    echo 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo; 
} else { 
    echo 'Message has been sent.'; 
}
$sql1 = "INSERT INTO users(username,password) VALUES (?,?)";
$stmt1 = mysqli_prepare($link,$sql1);
mysqli_stmt_bind_param($stmt1,'ss',$username,$password);
mysqli_stmt_execute($stmt1);
mysqli_stmt_close($stmt1);
$sql2 = "INSERT INTO user_data(epic_no,email,username,age,gender) VALUES (?,?,?,?,?)";
$stmt2 = mysqli_prepare($link,$sql2);
mysqli_stmt_bind_param($stmt2,'sssis',$epic_no,$email,$username,$age,$gender);
mysqli_stmt_execute($stmt2);
mysqli_stmt_close($stmt2);
$sql3 = "DELETE FROM users_approval WHERE id= ?";
$stmt3 = mysqli_prepare($link,$sql3);
mysqli_stmt_bind_param($stmt3,'i',$id);
mysqli_stmt_execute($stmt3);
mysqli_stmt_close($stmt3);
header("location: user-approval.php");
?>
