# online-voting
Secure Online Voting System
> Pre-requsites
* PhP
* XAMPP or WAMPP Server to run locally
* PhP mailer and composer
* SMTP Account if you want to send vote confirmation e-mail

# What all to be done
* Put your smtp credentials in required files([approve.php](approve.php),[voted-detail.php](voted-detail.php),[register.php](register.php))
* Open phpmyadmin
* Import [dbms.sql](dbms.sql) by creating a new database: dbms
* Enter a new password in the admin table in order to access admin area
* Use this password in the admin.php file to successfully login

